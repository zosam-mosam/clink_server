package com.josam.clink;

import java.util.Map;

public class ResponseVO {
	
	String success;
	String statusCode;
//	우쨔지
//	Map<String, Map<>> data;
}
