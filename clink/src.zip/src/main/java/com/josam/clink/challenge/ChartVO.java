package com.josam.clink.challenge;

import lombok.Data;

@Data
public class ChartVO {

	private String date;
	private long c1;
	private long c2;
	private long c3;
	private long c4;
	private long c5;
	private long c6;
	private long c7;
	private long c8;
	private long c9;
}
