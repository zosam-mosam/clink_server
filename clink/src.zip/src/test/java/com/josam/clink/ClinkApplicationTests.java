package com.josam.clink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
