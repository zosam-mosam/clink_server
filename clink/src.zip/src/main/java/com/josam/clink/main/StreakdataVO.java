package com.josam.clink.main;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class StreakdataVO {

	private String day;
	private BigDecimal value;

}
